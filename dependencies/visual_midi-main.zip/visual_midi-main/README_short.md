# Visual MIDI

Converts a [pretty midi](https://craffel.github.io/pretty-midi/) sequence to a [bokeh plot](https://bokeh.pydata.org/en/latest/).

## Installation

```bash
pip install visual_midi
```

## Usage

See full documentation at [Visual MIDI - GitHub](https://github.com/dubreuia/visual_midi).
